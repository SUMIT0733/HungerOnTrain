package com.HOT.star_0733.hottrain;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.HOT.star_0733.hottrain.R;

public class Search extends AppCompatActivity {

      @Override
      protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_search);
      }
}
