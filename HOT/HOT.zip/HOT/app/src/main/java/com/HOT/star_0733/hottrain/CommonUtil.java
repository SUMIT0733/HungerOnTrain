package com.HOT.star_0733.hottrain;

public class CommonUtil {
    public static final String url = "http://hungerontrain.tk/android_user/";
    public static final String Train_API = "evndob9pfc";

}
