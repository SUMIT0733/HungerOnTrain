package com.HOT.star_0733.hottrain.model;

public class Station_list {
    public String name;

    public Station_list(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
