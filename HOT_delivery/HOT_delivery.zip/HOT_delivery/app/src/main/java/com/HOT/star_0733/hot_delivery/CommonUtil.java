package com.HOT.star_0733.hot_delivery;

public class CommonUtil {
      public static final String url = "http://hungerontrain.tk/android_user/";
      public static final String Train_API = "x3fvadmnav";
      public static String  Pref = "HOT_DELIVERY";

}